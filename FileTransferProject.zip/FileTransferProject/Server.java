import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetAddress;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.OutputStreamWriter;
import java.util.Scanner;
import java.io.*;

public class Server
{
    public static Socket clientSocket;
    public static ServerSocket serverSocket;
    public static File directory;
    public static void main(String[] args) throws Exception {
        System.out.println("SERVER MAIN METHOD");
        directory = new File("D:\\BlueJ Projects\\FileTransferProject\\Files");
        String myIP = InetAddress.getLocalHost().getHostAddress();
        int myPort = 50000;
        serverSocket = new ServerSocket(myPort);
        System.out.println("HOSTING SERVER ON " + myIP + ":"  +myPort);
        System.out.println("WATING FOR SOMEONE TO CONNECT...");
        clientSocket = serverSocket.accept();
        System.out.println("SOMEONE CONNECTED TO THE SERVER");

        String theirIP = clientSocket.getInetAddress().getHostAddress();
        int theirPort = clientSocket.getPort();
        System.out.println("THEIR INFO IS " + theirIP + ":"  +theirPort);

        Thread talkThread = new Thread(new TalkThread(clientSocket));
        Thread listenThread = new Thread(new ListenThread(clientSocket));

        talkThread.start();
        listenThread.start();
        talkThread.join();
        listenThread.join();

    }

    private static class TalkThread implements Runnable{
        private static Socket socket;
        private static OutputStreamWriter osw;
        private static PrintWriter pw;

        public TalkThread(Socket s){
            socket = s;
        }

        public void run(){
            try{
                System.out.println("Talk Thread Started");
                osw = new OutputStreamWriter(socket.getOutputStream());
                pw = new PrintWriter(osw,true);
                Scanner scan = new Scanner(System.in);
                while(!socket.isClosed()){
                    String message  = scan.nextLine();
                    pw.println(message);
                }
            }
            catch(Exception e){e.printStackTrace();}

        }

        public static void listFiles(){
            for(File x: directory.listFiles()){
                pw.println(x.getName());
            }
        }

        public static void sendFile(String fileName) throws InterruptedException, IOException {
            pw.println("Sending File");
            File file = new File("D:\\BlueJ Projects\\FileTransferProject\\Files\\" + fileName); 
            FileInputStream fis = new FileInputStream(file);           
            BufferedInputStream bis = new BufferedInputStream(fis);                     
            //Get socket's output stream           
            OutputStream os = clientSocket.getOutputStream();                  
            //Read File Contents into contents array            
            byte[] contents;            
            long fileLength = file.length();
            System.out.println(fileLength + "length");
            //Thread.sleep(5000);
            long current = 0;         
            while(current!=fileLength){              
                int size = 100000;             
                if(fileLength - current >= size){                 
                    current += size;
                }
                else{                  
                    size = (int)(fileLength - current);                  
                    current = fileLength;             
                }
                contents = new byte[size];
                bis.read(contents, 0, size);
                os.write(contents);
                System.out.println("\fSending file ... "+(current*100)/fileLength+"% complete!");
                Thread.sleep(1000/60);
            }
            os.flush();
            //File transfer done. Close the socket connection!
            clientSocket.close();
            serverSocket.close();
            System.out.println("File sent succesfully!");
        }
    }
    private static class ListenThread implements Runnable{
        private Socket socket ;
        public ListenThread(Socket s){
            socket = s;
        }

        public void run(){
            
            try{
                System.out.println("Listen Thread Started");
                InputStreamReader isr = new InputStreamReader(socket.getInputStream());
                BufferedReader br = new BufferedReader(isr);
              
                while(!socket.isClosed()){
                    String message = br.readLine();
                    System.out.println(message);
                    if(message.equalsIgnoreCase("List files")){
                        System.out.println("attempting to list files");
                        TalkThread.listFiles();
                    }
                    else if(message.toLowerCase().contains("download")){
                        TalkThread.sendFile(message.substring(9));
                    }
                    else{
                        //cry
                    }

                }
            }
            catch(Exception e){e.printStackTrace();}

        }
    }
}
