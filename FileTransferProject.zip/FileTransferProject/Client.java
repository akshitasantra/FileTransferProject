import java.net.Socket;
import java.net.InetAddress;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.OutputStreamWriter;
import java.util.Scanner;
import java.io.*;

public class Client
{
    public static String userName;
    public static File directory;
    public static String downloadFileName;
    public static void main(String[] args)  {
        try{
            System.out.println("CLIENT MAIN METHOD");
            String myIP = InetAddress.getLocalHost().getHostAddress();
            int myPort = 50000;

            Scanner scan = new Scanner(System.in);
            System.out.print("Enter ip to connect to:".toUpperCase());
            String theirIP = scan.nextLine();
            System.out.println("ENTER PORT TO CONNECT TO:");
            int theirPort = scan.nextInt();scan.nextLine();
            System.out.println("TRYING TO CONNECT TO SERVER...");

            Socket socket = new Socket(theirIP,theirPort);
            System.out.println("...SUCCESSFULLY CONNECTED");

            System.out.println("Please state your name");
            userName = scan.nextLine();

            directory = new File("C:\\Users\\" + userName + "\\Downloads");

            Thread talkThread = new Thread(new TalkThread(socket));
            Thread listenThread = new Thread(new ListenThread(socket));

            talkThread.start();
            listenThread.start();
            listenThread.join();
        }
        catch(Exception e){e.printStackTrace();}
    }
    private static class TalkThread implements Runnable{
        private Socket socket ;
        public TalkThread(Socket s){
            socket = s;
        }

        public void run(){
            try{
                System.out.println("Talk Thread Started");
                OutputStreamWriter osw = new OutputStreamWriter(socket.getOutputStream());
                PrintWriter pw  = new PrintWriter(osw,true);
                Scanner scan = new Scanner(System.in);
                while(!socket.isClosed()){
                    String message  = scan.nextLine();

                    if(message.toLowerCase().startsWith("download")){
                        downloadFileName = message.substring(message.indexOf(" ")+1);
                    }
                    pw.println(message);
                }
            }
            catch(Exception e){e.printStackTrace();}

        }
    }
    private static class ListenThread implements Runnable{
        private static Socket socket ;
        public ListenThread(Socket s){
            socket = s;
        }

        public void run(){
            try{
                System.out.println("Listen Thread Started");
                InputStreamReader isr = new InputStreamReader(socket.getInputStream());
                BufferedReader br = new BufferedReader(isr);
                while(!socket.isClosed()){
                    String message = br.readLine();
                    System.out.println(message);
                    if(message.equals("Sending File")){
                        recieveFile();
                    }
                }
            }
            catch(Exception e){e.printStackTrace();}

        }

        public static void recieveFile(){
            try{

                byte[] contents = new byte[100000];

                //FileOutputStream fos = new FileOutputStream("C:\\Users\\yoghu\\Downloads\\"+directory);
                FileOutputStream fos = new FileOutputStream("C:\\Users\\30381\\Downloads\\"+downloadFileName);
                
                BufferedOutputStream bos = new BufferedOutputStream(fos);
                InputStream is = socket.getInputStream();
                //No of bytes read in one read() call
                int bytesRead = 0;

                while((bytesRead = is.read(contents))!=-1){
                    bos.write(contents, 0, bytesRead);
                }
                bos.flush();
                fos.close();
                is.close();
                socket.close();

                System.out.println("File saved successfully!");
            }
            catch(Exception e){e.printStackTrace();}
        }
    }
}
